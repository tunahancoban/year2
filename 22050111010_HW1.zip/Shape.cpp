#include "Shape.h"
#include <iostream>
void Shape::draw(){}